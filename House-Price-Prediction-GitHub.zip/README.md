# 🏠 House Price Prediction – Machine Learning Project

An end-to-end machine learning project to predict house prices.

## Tech Stack
- Python
- Pandas, NumPy
- Scikit-learn

## Workflow
- Data preprocessing
- Feature scaling
- Model training
- Evaluation

## How to Run
```bash
pip install -r requirements.txt
python src/train.py
python src/evaluate.py
python app.py
```
