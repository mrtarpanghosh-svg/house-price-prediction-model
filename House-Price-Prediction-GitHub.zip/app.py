import joblib
import numpy as np

model = joblib.load("random_forest.pkl")
sample = np.array([[1200, 3, 2, 10]])
print("Predicted Price:", model.predict(sample)[0])
