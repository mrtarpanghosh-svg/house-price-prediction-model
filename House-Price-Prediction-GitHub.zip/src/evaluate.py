import joblib
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score
from preprocess import load_and_preprocess_data

X_train, X_test, y_train, y_test = load_and_preprocess_data("data/housing.csv")

lr = joblib.load("linear_regression.pkl")
rf = joblib.load("random_forest.pkl")

lr_pred = lr.predict(X_test)
rf_pred = rf.predict(X_test)

print("LR RMSE:", np.sqrt(mean_squared_error(y_test, lr_pred)))
print("RF RMSE:", np.sqrt(mean_squared_error(y_test, rf_pred)))
