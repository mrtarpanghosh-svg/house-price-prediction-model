from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from preprocess import load_and_preprocess_data
import joblib

X_train, X_test, y_train, y_test = load_and_preprocess_data("data/housing.csv")

lr = LinearRegression()
lr.fit(X_train, y_train)

rf = RandomForestRegressor(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

joblib.dump(lr, "linear_regression.pkl")
joblib.dump(rf, "random_forest.pkl")

print("Models trained and saved")
